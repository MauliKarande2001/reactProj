import { Route, BrowserRouter as Router, Routes } from "react-router-dom";
import "./App.css";
import { AddUser } from "./component/AddUser";
import DashboardPage from "./component/DashboardPage";
import { ListUser } from "./component/ListUser";
import Login from "./component/Login";
import RegisterPage from "./component/RegisterPage";
import Profile from "./component/Profile";
import { useCookies } from "react-cookie";

function App() {
  const [cookies] = useCookies(['jwt']);

  return (
    <>
      <Router>
        {/* <div className="App" /> */}
        <div>
          <Routes>
            <Route path="/" Component={Login}></Route>
            <Route path="/register" Component={RegisterPage}></Route>
            {/* { cookies.jwt ? <Route path="/dashboard" Component={DashboardPage}></Route> : <Route path="/" Component={Login}></Route>} */}
           
            <Route path="/dashboard" Component={cookies.jwt ? DashboardPage: Login}></Route>

            <Route path="/profile" Component={Profile}></Route>

            <Route path="/listUser" Component={ListUser}></Route>
            <Route path="/add-user" Component={AddUser}></Route>
            <Route path="/update-user/:id" Component={AddUser}></Route>

             {/* <Route path="/api" Component={Test}></Route> */}
            {/* <Route path="/api" Component={ApiComponent}></Route> */}
          </Routes>
        </div>
      </Router>
    </>
  );
}

export default App;
