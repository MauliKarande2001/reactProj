import axios from "axios";

const REGISTER_USER = "http://localhost:8080/auth/addNewUser";
const LOGIN = "http://localhost:8080/auth/generateToken";

const TEST = "http://localhost:8080/auth/user/userProfile";


// const token = document.cookie.split('; ').find(row => row.startsWith('token')).split('=')[1];


// axios.interceptors.request.use(config => {
//     config.headers.Authorization = `Bearer ${token}`;
//     return config;
//   });

class RegisterAndLoginService {

  constructor(token) {
    this.token = token;
  }

  registerUser(registerUserData) {
    return axios.post(REGISTER_USER, registerUserData);
  }

  login(credentials){
    return axios.post(LOGIN, credentials);
  }

  methodCall(token){
      return axios.get(TEST, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
  }

 
}

export default new RegisterAndLoginService();
