import axios from "axios";

const GET_ALL_USER = "http://localhost:8080/crud/admin/getUsers";
const SAVE_USER = "http://localhost:8080/crud/admin/insertUser";
const GET_USER_BY_ID = "http://localhost:8080/crud/admin/getUserById";
const UPDATE_USER = "http://localhost:8080/crud/admin/updateUser";
const DELETE_USER = "http://localhost:8080/crud/admin/deleteById";

class UserService {

  getAllUsers(token, page, pageSize) {
    return axios.get(GET_ALL_USER, {
      headers: {
        Authorization: `Bearer ${token}`
      },
      params: {
        page: page,
        size: pageSize
      }
    });
}

  saveUser(emp,token) {
    return axios.post(SAVE_USER, emp, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
  }

  getUserById(id, token) {
    return axios.get(GET_USER_BY_ID + "/" + id, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
  }

  updateUser(empId, employee, token) {
    return axios.put(UPDATE_USER + "/" + empId, employee, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
  }

  deleteUser(empId, token) {
    return axios.delete(DELETE_USER + "/" + empId, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
  }
}

export default new UserService();
