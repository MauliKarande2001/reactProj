import React from 'react'
import { Typography, Grid, Paper } from '@mui/material';

const Grids = () => {
  return (
    <>
    <Grid container spacing={2}>
          <Grid item xs={3}>
            <Paper className="paper">
              <img src="dashboardImg\weekly_sales.png" alt="Weekly Sales" className="image" />
              <div>
                <Typography variant="h5" style={{ fontWeight: 'bold' }}>714k</Typography>
                <Typography variant="body1" className="text">Weekly Sales</Typography>
              </div>
            </Paper>
          </Grid>

          <Grid item xs={3}>
            <Paper className="paper">
              <img src="dashboardImg\new_users.png" alt="New Users" className="image" />
              <div>
                <Typography variant="h5" style={{ fontWeight: 'bold' }}>1.35m</Typography>
                <Typography variant="body1" className="text">New Users</Typography>
              </div>
            </Paper>
          </Grid>

          <Grid item xs={3}>
            <Paper className="paper">
              <img src="dashboardImg\item_orders.png" alt="Item Orders" className="image" />
              <div>
                <Typography variant="h5" style={{ fontWeight: 'bold' }}>1.72m</Typography>
                <Typography variant="body1" className="text">Item Orders</Typography>
              </div>
            </Paper>
          </Grid>

          <Grid item xs={3}>
            <Paper className="paper">
              <img src="dashboardImg\bug_reports.png" alt="Bug Reports" className="image" />
              <div>
                <Typography variant="h5" style={{ fontWeight: 'bold' }}>234</Typography>
                <Typography variant="body1" className="text">Bug Reports</Typography>
              </div>
            </Paper>
          </Grid>
        </Grid>
    </>
  )
}

export default Grids