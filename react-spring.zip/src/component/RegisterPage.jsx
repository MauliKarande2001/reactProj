import React, { useState } from 'react';
import { TextField, Button, Container, Typography,MenuItem, Link  } from '@mui/material';
import RegisterAndLoginService from '../services/RegisterAndLoginService';
import { Alert, AlertTitle } from '@mui/material';

function RegisterPage() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [roles, setRole] = useState('');
  const [errors, setErrors] = useState({});
  const [alertMessage, setAlertMessage] = useState('');
  const [alertType, setAlertType] = useState('success');

  const handleSubmit = (e) => {
    e.preventDefault();

    // Simple validation
    if (!name || !email || !password || !confirmPassword || password !== confirmPassword || !roles) {
      setErrors({
        name: !name,
        email: !email,
        password: !password,
        confirmPassword: password !== confirmPassword,
        role: !roles,
      });
      return;
    }
     // Email validation
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email.match(emailPattern)) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        email: true,
      }));
      return;
    }

    // Add your registration logic here
    console.log('Registering with:', name, email, password, roles);

    const registerUserData = { name, password, roles, email };
    console.log(registerUserData);

   
      RegisterAndLoginService.registerUser(registerUserData)
        .then((response) => {
            console.log(response.data);
            setAlertMessage(response.data);
            setAlertType('success');
        //   navigate("/");
        })
        .catch((error) => {
          console.log(error);
          setAlertMessage('Failed to register user');
          setAlertType('failed');
        });
    

    // Reset form
    setName('');
    setEmail('');
    setPassword('');
    setConfirmPassword('');
    setRole('');
    setErrors({});
  };

  const handleAlertClose = () => {
    setAlertMessage('');
  };


  return (
    <Container maxWidth="sm">
      <Typography variant="h4" align="center" gutterBottom>
        Register
      </Typography>
     
      <div>
      {alertMessage && (
        <Alert severity={alertType} onClose={handleAlertClose}>
          <AlertTitle>{alertType === 'error' ? 'Error' : 'Success'}</AlertTitle>
          {alertMessage}
        </Alert>
      )}
        </div>
      <form onSubmit={handleSubmit}>
        <TextField
          label="Name"
          fullWidth
          value={name}
          onChange={(e) => setName(e.target.value)}
          error={errors.name}
          helperText={errors.name ? 'Name is required' : ''}
          margin="normal"
          variant="outlined"
        />
        <TextField
          label="Email"
          fullWidth
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          error={errors.email}
          helperText={errors.email ? 'Email is required' : ''}
          margin="normal"
          variant="outlined"
        />
        <TextField
          label="Password"
          fullWidth
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          error={errors.password}
          helperText={errors.password ? 'Password is required' : ''}
          margin="normal"
          variant="outlined"
        />
        <TextField
          label="Confirm Password"
          fullWidth
          type="password"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          error={errors.confirmPassword}
          helperText={errors.confirmPassword ? 'Passwords do not match' : ''}
          margin="normal"
          variant="outlined"
        />

        <TextField
          select
          label="Role"
          fullWidth
          value={roles}
          onChange={(e) => setRole(e.target.value)}
          error={errors.role}
          helperText={errors.role ? 'Role is required' : ''}
          margin="normal"
          variant="outlined"
        >
          <MenuItem value="ROLE_USER">User</MenuItem>
          <MenuItem value="ROLE_ADMIN">Admin</MenuItem>
        </TextField>
        <Button type="submit" variant="contained" color="primary" fullWidth>
          Register
        </Button>

        <Typography variant="body1" align="center">
            If yoy have allready account <Link href="/">Login here</Link>
          </Typography>
      </form>
    </Container>
  );
}

export default RegisterPage;
