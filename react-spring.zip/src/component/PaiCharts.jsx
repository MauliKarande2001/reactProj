import * as React from 'react';
//import { DefaultizedPieValueType } from '@mui/x-charts';
import { PieChart, pieArcLabelClasses } from '@mui/x-charts/PieChart';
import { Typography, Grid, Paper } from '@mui/material';
import BarAndLines from './BarAndLines';

const data = [
  { label: 'US', value: 400, color: '#0088FE' },
  { label: 'Asia', value: 300, color: '#00C49F' },
  { label: 'Europe', value: 300, color: '#FFBB28' },
  { label: 'Africa', value: 200, color: '#FF8042' },
];

const sizing = {
  margin: { right: 5 },
  width: 200,
  height: 396,
  legend: { hidden: true },
};
const TOTAL = data.map((item) => item.value).reduce((a, b) => a + b, 0);

const getArcLabel = (params) => {
  const percent = params.value / TOTAL;
  return `${(percent * 100).toFixed(0)}%`;
};

const PieCharts = () => {
  return (
    <>
    
    <Grid container spacing={2} style={{ display: 'flex', justifyContent: 'flex-start', flexDirection: 'row', alignItems: 'flex-start' }}>

    <BarAndLines/>

    <Grid item xs={3}>
    <Paper className="paper" style={{ display: 'flex', justifyContent: 'flex-end', flexDirection: 'column', alignItems: 'flex-end' }}>
    <div style={{ display: 'flex', justifyContent: 'flex-end', flexDirection: 'column', alignItems: 'flex-end' }}>
    <div style={{ marginRight: '40px', fontWeight: 'bold',marginBottom: '20px'   }}>  Current Visitiors </div>
    <PieChart
      series={[
        {
          outerRadius: 100,
          data,
          arcLabel: getArcLabel,
        },
      ]}
      sx={{
        [`& .${pieArcLabelClasses.root}`]: {
          fill: 'white',
          fontSize: 15,
        },
      }}
      {...sizing}
    />
    <div style={{ display: 'flex', flexDirection: 'row', alignItems: 'flex-end', marginTop: '20px' }}>
      {data.map((item) => (
        <div key={item.label} style={{ display: 'flex', alignItems: 'center', margin: '0 4px' }}>
          <div style={{ width: '10px', height: '10px', borderRadius: '50%', backgroundColor: item.color, marginRight: '1px' }}></div>
          <div>{item.label}</div>
        </div>
      ))}
    </div>
  </div>
  </Paper>
  </Grid>
  </Grid>
  </>
  );
};

export default PieCharts;
