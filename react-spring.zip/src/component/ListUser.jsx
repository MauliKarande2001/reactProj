import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useCookies } from "react-cookie";
import UserService from "../services/UserService";

export const ListUser = () => {
    const [users, setUsers] = useState([]);
    const [cookies] = useCookies(['jwt']);
    const [page, setPage] = useState(0);
    const [totalPages, setTotalPages] = useState(0);
    const [pageSize, setPageSize] = useState(2); // Number of records per page
    const [pageSized, setPageSized] = useState(2);

    useEffect(() => {
        const jwtToken = cookies.jwt;
        UserService.getAllUsers(jwtToken, page, pageSize)
            .then((response) => {
                setUsers(response.data.content);
                setTotalPages(response.data.totalPages);
            })
            .catch((error) => {
                console.log(error);
            });
    }, [cookies.jwt, page, pageSize]);

    const deleteUser = (id) => {
        const token = cookies.jwt;
        UserService.deleteUser(id, token)
            .then(() => {
                // Reload data
                UserService.getAllUsers(token, page, pageSize)
                    .then((response) => {
                        setUsers(response.data.content);
                        setTotalPages(response.data.totalPages);
                    })
                    .catch((error) => {
                        console.log(error);
                    });
            })
            .catch((error) => {
                console.log(error);
            });
    };

    const handlePageChange = (pageNumber) => {
        setPage(pageNumber - 1); // Page numbers start from 0 in Spring Boot
    };

    const handleNextPage = () => {
        if (page < totalPages - 1) {
            setPage(page + 1);
        }
    };

    const handlePrevPage = () => {
        if (page > 0) {
            setPage(page - 1);
        }
    };

    const handlePageSizeChange = (event) => {
        setPageSize(parseInt(event.target.value, 10));
        setPage(0); // Reset to first page when changing page size
    };

    return (
        <div className="container">
            <br />
            <h2 className="text-center">User Info...!</h2>

            <Link to="/add-user" className="btn btn-primary mb-2">
                Add User
            </Link>
            <div className="mb-2">
                Records per page:{" "}
                <select value={pageSize} onChange={handlePageSizeChange}>
                    <option value={pageSized}>{pageSized}</option>
                    <option value="5">5</option>
                    <option value="10">10</option>
                </select>
            </div>
            <table className="table table-bordered table-stripped">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Age</th>
                        <th>Address</th>
                        <th>Phone</th>
                        <th>Designation</th>
                        <th>Email</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {users.map((user) => (
                        <tr key={user.id}>
                            <td>{user.id}</td>
                            <td>{user.name}</td>
                            <td>{user.age}</td>
                            <td>{user.address}</td>
                            <td>{user.phone}</td>
                            <td>{user.designation}</td>
                            <td>{user.email}</td>
                            <td>
                                <Link className="btn btn-info" to={`/update-user/${user.id}`}>
                                    Update
                                </Link>
                                <button
                                    className="btn btn-danger mx-2"
                                    onClick={() => {
                                        deleteUser(user.id);
                                    }}
                                >
                                    Delete
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
            <div className="d-flex justify-content-between">
                <div>
                    Showing page {page + 1} of {totalPages}
                </div>
                <div>
                    <button className="btn btn-primary" onClick={handlePrevPage}>
                        Previous
                    </button>
                    <button className="btn btn-primary mx-2" onClick={handleNextPage}>
                        Next
                    </button>
                </div>
            </div>
        </div>
    );
};
