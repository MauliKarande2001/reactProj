import React from 'react'
import { useCookies } from 'react-cookie';

const Test = () => {
    const [cookies] = useCookies(['jwt']);
    const jwtToken = cookies.jwt;
  return (<>
    <div>Test</div>
    <h1>{jwtToken}</h1>
    </>
    
  )
}

export default Test