import React from 'react';
import { Typography, Grid, Paper } from '@mui/material';
import { ResponsiveChartContainer } from '@mui/x-charts/ResponsiveChartContainer';
import { LinePlot } from '@mui/x-charts/LineChart';
import { BarPlot } from '@mui/x-charts/BarChart';
import { ChartsXAxis } from '@mui/x-charts/ChartsXAxis';
import { ChartsYAxis } from '@mui/x-charts/ChartsYAxis';
import { ChartsTooltip } from '@mui/x-charts/ChartsTooltip';

const data = [
  { label: 'Team A', color: '#0088FE' },
  { label: 'Team B',  color: '#00C49F' },
  { label: 'Team C', color: '#FFBB28' },
];

const dataset = [
  { min: 20, max: 30, precip: 60, month: 'Apr' },
  { min: 8, max: 17, precip: 105, month: 'Mai' },
  { min: 90, max: 120, precip: 114, month: 'Jun' },
  { min: 18, max: 26, precip: 106, month: 'Jul' },
  { min: 60, max: 70, precip: 105, month: 'Aug' },
  { min: 100, max: 140, precip: 100, month: 'Sept' },
  { min: 30, max: 40, precip: 116, month: 'Oct' },
  { min: 15, max: 25, precip: 93, month: 'Nov' },
];

const series = [
  { type: 'line', dataKey: 'min', color: '#577399' },
  { type: 'line', dataKey: 'max', color: '#fe5f55' },
  { type: 'bar', dataKey: 'precip', color: '#bfdbf7', yAxisKey: 'leftAxis' },
];

export default function TemperatureChart() {

  return (
    <Grid item xs={9}>
    <Paper className="paper" style={{ display: 'flex', justifyContent: 'flex-start', flexDirection: 'column', alignItems: 'flex-start' }}>
    <div style={{ marginRight: '40px', fontWeight: 'bold', marginLeft: '20px' }}>Website Visits</div>
        <Typography variant="body1" className="text" style={{ marginLeft: '20px' }}>(+43%) than last year</Typography>
       
        <div style={{ display: 'flex', flexDirection: 'row', alignItems: 'flex-end', marginTop: '20px', marginLeft: 'auto' }}>
  {data.map((item) => (
    <div key={item.label} style={{ display: 'flex', alignItems: 'center', margin: '0 4px' }}>
      <div style={{ width: '10px', height: '10px', borderRadius: '50%', backgroundColor: item.color, marginRight: '1px' }}></div>
      <div>{item.label}</div>
    </div>
  ))}
</div>



      <ResponsiveChartContainer
        series={series}
        xAxis={[{ scaleType: 'band', dataKey: 'month', label: 'Month' }]}
        yAxis={[
          { id: 'leftAxis', label: ''},
          { id: 'rightAxis', position: '', label: '', ticks: { display: false } }, // Hide ticks for right Y-axis
        ]}
        dataset={dataset}
        height={393}
        style={{ width: '400px' }} 
      >
     
    <BarPlot />

        <LinePlot />
        <ChartsXAxis />
        <ChartsYAxis axisId="leftAxis" />
        <ChartsTooltip />
      </ResponsiveChartContainer>
     
    </Paper>
  </Grid>
  
  
  );
}
