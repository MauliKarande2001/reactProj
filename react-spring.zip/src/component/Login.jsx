import React, { useState } from 'react';
import { TextField, Button, Container, Typography,Link  } from '@mui/material';
import { Alert, AlertTitle } from '@mui/material';
import RegisterAndLoginService from '../services/RegisterAndLoginService';
import { useCookies } from 'react-cookie';
import { Navigate, useNavigate } from 'react-router-dom';
//import { useHistory } from 'react-router-dom';

function Login() {
    const [username, setUserName] = useState('');
    const [password, setPassword] = useState('');
    const [errors, setErrors] = useState({});
    const [alertMessage, setAlertMessage] = useState('');
    const [alertType, setAlertType] = useState('success');
    const [cookies, setCookie] = useCookies(['jwt']);

const navigate = useNavigate();
    //const history = useHistory();
   
    const handleSubmit = (e) => {
      e.preventDefault();
  
      // Simple validation
      if (!username || !password) {
        setErrors({ username: !username, password: !password });
        return;
      }
  
      // Add your login logic here
      console.log('Logging in with:', username, password);
      const credentials = {   username, password };
     
      RegisterAndLoginService.login(credentials)
        .then((response) => {
            var jwtToken = response.data;
            setCookie('jwt', jwtToken, { path: '/' });

             navigate("/dashboard");
            // history.push('/dashboard');
        })
        .catch((error) => {
          console.log(error);
          setAlertMessage('Username or Password is invalid');
          setAlertType('error');
        });
  
      // Reset form
      setUserName('');
      setPassword('');
      setErrors({});
    };

    const handleAlertClose = () => {
        setAlertMessage('');
      };
   
  
    return (
      <Container maxWidth="sm">
        <Typography variant="h4" align="center" gutterBottom>
          Login
        </Typography>
        <div>
      {alertMessage && (
        <Alert severity={alertType} onClose={handleAlertClose}>
          <AlertTitle>{alertType === 'error' ? 'Error' : 'Success'}</AlertTitle>
          {alertMessage}
        </Alert>
      )}
        </div>
        <form onSubmit={handleSubmit}>
          <TextField
            label="UserName"
            fullWidth
            value={username}
            onChange={(e) => setUserName(e.target.value)}
            error={errors.userName}
            helperText={errors.userName ? 'userName is required' : ''}
            margin="normal"
            variant="outlined"
          />
          <TextField
            label="Password"
            fullWidth
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            error={errors.password}
            helperText={errors.password ? 'Password is required' : ''}
            margin="normal"
            variant="outlined"
          />
          <Button type="submit" variant="contained" color="primary" fullWidth>
            Login
          </Button>

          <Typography variant="body1" align="center">
            Don't have an account? <Link href="/register">Register</Link>
          </Typography>
        </form>

      </Container>
    );
}

export default Login