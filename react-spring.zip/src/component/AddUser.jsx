import { useState, useEffect } from "react";
import React from "react";
import UserService from "../services/UserService";
import { useNavigate, useParams } from "react-router-dom";
import { useCookies } from 'react-cookie';

export const AddUser = () => {
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [address, setaddress] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [designation, setDesignation] = useState("");
  const [cookies, setCookie, removeCookie] = useCookies(['jwt']);


  let navigate = useNavigate();
  const { id } = useParams();

  const saveOrUpdateUser = (e) => {
    e.preventDefault();
    const emp = { name, age, address, email, phone, designation };
    const jwtToken = cookies.jwt;

    if (id) {
      emp.id = id;
      
      UserService.updateUser(id, emp,jwtToken)
        .then((response) => {
          navigate("/dashboard");
        })
        .catch((error) => {
          console.log(error);
        });
    } else {
      UserService.saveUser(emp,jwtToken)
        .then((response) => {
          navigate("/dashboard");
        })
        .catch((error) => {
          console.log(error);
        });
    }
  };

  useEffect(() => {
    const token = cookies.jwt;
    UserService.getUserById(id, token)
      .then((response) => {
        setName(response.data.name);
        setAge(response.data.age);
        setaddress(response.data.address);
        setEmail(response.data.email);
        setDesignation(response.data.designation);
        setPhone(response.data.phone);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  const title = () => {
    if (id) {
      return <h2>Update User...!</h2>;
    } else {
      return <h2>Add User...!</h2>;
    }
  };

  return (
    <div className="container">
      <br />
      <br />
      <div className="row">
        <div className="card col-md-6 offset-md-3 offset-md-3">
          {/* <h2 className="text-center">Add Employee</h2> */}
          {title()}
          <div className="card-body">
            <form action="">
              <div className="form-group mb-2">
                <label className="form-label">Name :-</label>

                <input
                  type="text"
                  placeholder="Enter your name"
                  name="name"
                  className="form-control"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </div>

              <div className="form-group mb-2">
                <label className="form-label">Age :-</label>

                <input
                  type="text"
                  placeholder="Enter your age"
                  name="age"
                  className="form-control"
                  value={age}
                  onChange={(e) => setAge(e.target.value)}
                />
              </div>

              <div className="form-group mb-2">
                <label className="form-label">Address :-</label>

                <input
                  type="text"
                  placeholder="Enter your address"
                  name="address"
                  className="form-control"
                  value={address}
                  onChange={(e) => setaddress(e.target.value)}
                />
              </div>

           

              <div className="form-group mb-2">
                <label className="form-label">Phone :-</label>

                <input
                  type="text"
                  placeholder="Enter your phone number"
                  name="phone"
                  className="form-control"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                />
              </div>

              <div className="form-group mb-2">
                <label className="form-label">Designation :-</label>

                <input
                  type="text"
                  placeholder="Enter your Designation"
                  name="designation"
                  className="form-control"
                  value={designation}
                  onChange={(e) => setDesignation(e.target.value)}
                />
              </div>

              <div className="form-group mb-2">
                <label className="form-label">Email :-</label>

                <input
                  type="text"
                  placeholder="Enter your Email"
                  name="designation"
                  className="form-control"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>

              <button
                className="btn btn-success"
                onClick={(e) => saveOrUpdateUser(e)}
              >
                Submit
              </button>
              <button
                className="btn btn-danger mx-2"
                onClick={(e) => navigate("/dashboard")}
              >
                Cancel
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
