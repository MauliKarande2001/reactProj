import React, { useEffect, useState } from 'react'
import { useCookies } from 'react-cookie';

const Profile = () => {
    const [userRole, setUserRole] = useState(null);
    const [cookies, setCookie, removeCookie] = useCookies(['jwt']);


    useEffect(() => {
        // Check user role from JWT
        const jwtToken = cookies.jwt;
        console.log(jwtToken);
        if (jwtToken) {
          const decodedToken = parseJwt(jwtToken);
        //   console.log(decodedToken);
          setUserRole(decodedToken.role);
        }
      }, [cookies.jwt]);
    
      const parseJwt = (token) => {
        const base64Url = token.split('.')[1];
        const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        const jsonPayload = decodeURIComponent(atob(base64).split('').map((c) => `%${(`00${c.charCodeAt(0).toString(16)}`).slice(-2)}`).join(''));
    
        return JSON.parse(jsonPayload);
      };

  return (
    <>
    <div>
   { userRole === 'ROLE_ADMIN' ? 'Welcome to the ADMIN Profile. You have all the access' : 'Welcome to the USER profile.You dont have ADMIN Access.'}
    </div>
    </>
  )
}

export default Profile