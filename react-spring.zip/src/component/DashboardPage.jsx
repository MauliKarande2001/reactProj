import React, { useEffect } from 'react';
import { AppBar, Toolbar, Typography, Drawer, List, ListItem, ListItemIcon, ListItemText, IconButton, CssBaseline, Divider, Container, Menu, MenuItem, Grid, Paper } from '@mui/material';
import { Menu as MenuIcon, Dashboard as DashboardIcon, ShoppingCart as ShoppingCartIcon, People as PeopleIcon, BarChart as BarChartIcon, Layers as LayersIcon, Logout as LogoutIcon, Settings as SettingsIcon, Person as PersonIcon,ExitToApp as ExitToAppIcon,AccountCircle as AccountCircleIcon } from '@mui/icons-material';
// import {AccountCircle as AccountCircleIcon, Settings as SettingsIcon,ExitToApp as ExitToAppIcon,} from '@mui/icons-material';

import { ListUser } from './ListUser';
import { Navigate, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { useCookies } from 'react-cookie';
import Profile from './Profile';
import "../css/dashboard.css";
import PaiCharts from './PaiCharts';
import Grids from './Grids';
import BarAndLines from './BarAndLines';


function DashboardPage() {
  const [open, setOpen] = React.useState(false);
  const [selectedMenuItem, setSelectedMenuItem] = useState(null);
  const [cookies, setCookie, removeCookie] = useCookies(['jwt', 'username']);
  const [userRole, setUserRole] = useState(null);
  const [anchorEl, setAnchorEl] = useState(null);
  const [username, setUsername] = useState('');
  const [listUserFlag, setListUserFlag] = useState(false);


  useEffect(() => {
   
    // Check user role from JWT
    const jwtToken = cookies.jwt;
    if (jwtToken) {
      const decodedToken = parseJwt(jwtToken);
      setUserRole(decodedToken.role);
      setUsername(decodedToken.sub.toUpperCase())
      // setCookie('username', username);
    }
  }, [cookies.jwt]);

  const parseJwt = (token) => {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const jsonPayload = decodeURIComponent(atob(base64).split('').map((c) => `%${(`00${c.charCodeAt(0).toString(16)}`).slice(-2)}`).join(''));

    return JSON.parse(jsonPayload);
  };

  // useEffect(() => {
    
  //   return () => {
  //     if(listUserFlag){
  //     setSelectedMenuItem("Users");
  //     renderSelectedData();
  //     }
  //   }
  // }, [listUserFlag])
  

  const navigate = useNavigate();

  const handleDrawerOpen = () => {
    setOpen(true);
  };

  const handleDrawerClose = () => {
    setOpen(false);
  };

  const handleMenuClick = (item) => {
    if(item === 'profile')setAnchorEl(null);
    setSelectedMenuItem(item);
  };

  const handleLogout = () => {
    removeCookie('jwt');
    navigate('/');
  };

  const handleMenuClose = () => {
    setAnchorEl(null);

    //  handleMenuClick('profile');
  };

  const handleMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };


  const renderSelectedData = () => {
    switch (selectedMenuItem) {
      case 'Users':
        return userRole === 'ROLE_ADMIN' ? <ListUser /> : `403 Forbidden error - Sorry ${username.toLowerCase()} You dont have access`;
      case 'profile':
        return  <Profile />;
      case 'Orders':
        return null;
      case 'Reports':
        return null;
      default:
        return null;
    }
  };

  return (
    <div style={{ display: 'flex' }}>
      <CssBaseline />
      <AppBar position="fixed" sx={{ zIndex: (theme) => theme.zIndex.drawer + 1 }}>
        <Toolbar sx={{ justifyContent: 'space-between' }}>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            onClick={handleDrawerOpen}
            edge="start"
            sx={{ mr: 2 }}
          >
            <img
              src="spar.png"
              alt="Menu"
              style={{ width: 60, height: 30 }}
            />
          </IconButton>
          <Typography variant="h6" noWrap component="div">
            {userRole === 'ROLE_ADMIN' ? ` ${username} Admin` : `${username} User`} Dashboard 
          </Typography>

          <div>
            <IconButton
              color="inherit"
              aria-label="more"
              aria-controls="profile-menu"
              aria-haspopup="true"
              onClick={handleMenuOpen}
            >
              <MenuIcon />
            </IconButton>
            <Menu
              id="profile-menu"
              anchorEl={anchorEl}
              open={Boolean(anchorEl)}
              onClose={handleMenuClose}
            >
             <MenuItem>
    <ListItemIcon>
      <AccountCircleIcon fontSize="small" />
    </ListItemIcon>
    <ListItemText primary={` ${username.toLowerCase()} Profile`} onClick={() => handleMenuClick('profile')} />
  </MenuItem>
  <MenuItem>
    <ListItemIcon>
      <SettingsIcon fontSize="small" />
    </ListItemIcon>
    <ListItemText primary="Settings" />
  </MenuItem>
  <MenuItem onClick={handleLogout}>
    <ListItemIcon>
      <ExitToAppIcon fontSize="small" />
    </ListItemIcon>
    <ListItemText primary="Logout" />
  </MenuItem>
            </Menu>
          </div>

        </Toolbar>
      </AppBar>
      <Drawer
        variant="permanent"
        sx={{
          width: 240,
          flexShrink: 0,
          '& .MuiDrawer-paper': {
            width: 240,
            boxSizing: 'border-box',
          },
        }}
        open={open}
      >
        <Toolbar />
        <Divider />
        <List>
          <ListItem button>
            <ListItemIcon>
              <DashboardIcon />
            </ListItemIcon>
            <ListItemText primary="Dashboard" />
          </ListItem>
          <ListItem button>
            <ListItemIcon>
              <ShoppingCartIcon />
            </ListItemIcon>
            <ListItemText primary="Orders" />
          </ListItem>
          <ListItem button onClick={() => handleMenuClick('Users')}>
            <ListItemIcon>
              <PeopleIcon />
            </ListItemIcon>
            <ListItemText primary="Customers" />
          </ListItem>
          <ListItem button>
            <ListItemIcon>
              <BarChartIcon />
            </ListItemIcon>
            <ListItemText primary="Reports" />
          </ListItem>
          <ListItem button>
            <ListItemIcon>
              <LayersIcon />
            </ListItemIcon>
            <ListItemText primary="Integrations" />
          </ListItem>
        </List>
      </Drawer>
      <Container component="main" sx={{ flexGrow: 1, bgcolor: 'background.default', p: 3 }}>
        <Toolbar />
        <h3 style={{ marginTop: '10px', marginBottom: '20px', fontWeight: 'bold' }}>Hi, Welcome back {username} 👋</h3>

       <Grids/>

        <Typography variant="body1" gutterBottom style={{ marginTop: '30px' }}>
         <PaiCharts/>
         {/* <BarAndLines/> */}
         {renderSelectedData()}
        </Typography>
      </Container>

    </div>
  );
}

export default DashboardPage;

